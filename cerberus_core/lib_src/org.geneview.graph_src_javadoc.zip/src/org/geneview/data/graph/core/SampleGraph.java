/**
 * 
 */
package org.geneview.data.graph.core;

import org.geneview.graph.core.Graph;

/**
 * Example for a graph.
 * 
 * @author Michael Kalkusch
 *
 */
public class SampleGraph extends Graph {

	/**
	 * 
	 */
	public SampleGraph(final int id) {
		super(id);
		
		/** extend the Graph based on your requirements */
	}

}
