Run with e.g.

java -Dsun.java2d.noddraw=true demos.hdr.HDR demos/data/images/stpeters_cross.hdr 512 384 2 7 3 demos/data/models/teapot.obj
