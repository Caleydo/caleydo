/**
 * BundleSeqsAlignsType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.ncbi.www.soap.eutils.efetch;

public class BundleSeqsAlignsType  implements java.io.Serializable {
    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_sequencesType bundleSeqsAligns_sequences;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_seqalignsType bundleSeqsAligns_seqaligns;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_strucalignsType bundleSeqsAligns_strucaligns;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_importsType bundleSeqsAligns_imports;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_styleDictionaryType bundleSeqsAligns_styleDictionary;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_userAnnotationsType bundleSeqsAligns_userAnnotations;

    public BundleSeqsAlignsType() {
    }

    public BundleSeqsAlignsType(
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_sequencesType bundleSeqsAligns_sequences,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_seqalignsType bundleSeqsAligns_seqaligns,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_strucalignsType bundleSeqsAligns_strucaligns,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_importsType bundleSeqsAligns_imports,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_styleDictionaryType bundleSeqsAligns_styleDictionary,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_userAnnotationsType bundleSeqsAligns_userAnnotations) {
           this.bundleSeqsAligns_sequences = bundleSeqsAligns_sequences;
           this.bundleSeqsAligns_seqaligns = bundleSeqsAligns_seqaligns;
           this.bundleSeqsAligns_strucaligns = bundleSeqsAligns_strucaligns;
           this.bundleSeqsAligns_imports = bundleSeqsAligns_imports;
           this.bundleSeqsAligns_styleDictionary = bundleSeqsAligns_styleDictionary;
           this.bundleSeqsAligns_userAnnotations = bundleSeqsAligns_userAnnotations;
    }


    /**
     * Gets the bundleSeqsAligns_sequences value for this BundleSeqsAlignsType.
     * 
     * @return bundleSeqsAligns_sequences
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_sequencesType getBundleSeqsAligns_sequences() {
        return bundleSeqsAligns_sequences;
    }


    /**
     * Sets the bundleSeqsAligns_sequences value for this BundleSeqsAlignsType.
     * 
     * @param bundleSeqsAligns_sequences
     */
    public void setBundleSeqsAligns_sequences(gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_sequencesType bundleSeqsAligns_sequences) {
        this.bundleSeqsAligns_sequences = bundleSeqsAligns_sequences;
    }


    /**
     * Gets the bundleSeqsAligns_seqaligns value for this BundleSeqsAlignsType.
     * 
     * @return bundleSeqsAligns_seqaligns
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_seqalignsType getBundleSeqsAligns_seqaligns() {
        return bundleSeqsAligns_seqaligns;
    }


    /**
     * Sets the bundleSeqsAligns_seqaligns value for this BundleSeqsAlignsType.
     * 
     * @param bundleSeqsAligns_seqaligns
     */
    public void setBundleSeqsAligns_seqaligns(gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_seqalignsType bundleSeqsAligns_seqaligns) {
        this.bundleSeqsAligns_seqaligns = bundleSeqsAligns_seqaligns;
    }


    /**
     * Gets the bundleSeqsAligns_strucaligns value for this BundleSeqsAlignsType.
     * 
     * @return bundleSeqsAligns_strucaligns
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_strucalignsType getBundleSeqsAligns_strucaligns() {
        return bundleSeqsAligns_strucaligns;
    }


    /**
     * Sets the bundleSeqsAligns_strucaligns value for this BundleSeqsAlignsType.
     * 
     * @param bundleSeqsAligns_strucaligns
     */
    public void setBundleSeqsAligns_strucaligns(gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_strucalignsType bundleSeqsAligns_strucaligns) {
        this.bundleSeqsAligns_strucaligns = bundleSeqsAligns_strucaligns;
    }


    /**
     * Gets the bundleSeqsAligns_imports value for this BundleSeqsAlignsType.
     * 
     * @return bundleSeqsAligns_imports
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_importsType getBundleSeqsAligns_imports() {
        return bundleSeqsAligns_imports;
    }


    /**
     * Sets the bundleSeqsAligns_imports value for this BundleSeqsAlignsType.
     * 
     * @param bundleSeqsAligns_imports
     */
    public void setBundleSeqsAligns_imports(gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_importsType bundleSeqsAligns_imports) {
        this.bundleSeqsAligns_imports = bundleSeqsAligns_imports;
    }


    /**
     * Gets the bundleSeqsAligns_styleDictionary value for this BundleSeqsAlignsType.
     * 
     * @return bundleSeqsAligns_styleDictionary
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_styleDictionaryType getBundleSeqsAligns_styleDictionary() {
        return bundleSeqsAligns_styleDictionary;
    }


    /**
     * Sets the bundleSeqsAligns_styleDictionary value for this BundleSeqsAlignsType.
     * 
     * @param bundleSeqsAligns_styleDictionary
     */
    public void setBundleSeqsAligns_styleDictionary(gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_styleDictionaryType bundleSeqsAligns_styleDictionary) {
        this.bundleSeqsAligns_styleDictionary = bundleSeqsAligns_styleDictionary;
    }


    /**
     * Gets the bundleSeqsAligns_userAnnotations value for this BundleSeqsAlignsType.
     * 
     * @return bundleSeqsAligns_userAnnotations
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_userAnnotationsType getBundleSeqsAligns_userAnnotations() {
        return bundleSeqsAligns_userAnnotations;
    }


    /**
     * Sets the bundleSeqsAligns_userAnnotations value for this BundleSeqsAlignsType.
     * 
     * @param bundleSeqsAligns_userAnnotations
     */
    public void setBundleSeqsAligns_userAnnotations(gov.nih.nlm.ncbi.www.soap.eutils.efetch.BundleSeqsAligns_userAnnotationsType bundleSeqsAligns_userAnnotations) {
        this.bundleSeqsAligns_userAnnotations = bundleSeqsAligns_userAnnotations;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BundleSeqsAlignsType)) return false;
        BundleSeqsAlignsType other = (BundleSeqsAlignsType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.bundleSeqsAligns_sequences==null && other.getBundleSeqsAligns_sequences()==null) || 
             (this.bundleSeqsAligns_sequences!=null &&
              this.bundleSeqsAligns_sequences.equals(other.getBundleSeqsAligns_sequences()))) &&
            ((this.bundleSeqsAligns_seqaligns==null && other.getBundleSeqsAligns_seqaligns()==null) || 
             (this.bundleSeqsAligns_seqaligns!=null &&
              this.bundleSeqsAligns_seqaligns.equals(other.getBundleSeqsAligns_seqaligns()))) &&
            ((this.bundleSeqsAligns_strucaligns==null && other.getBundleSeqsAligns_strucaligns()==null) || 
             (this.bundleSeqsAligns_strucaligns!=null &&
              this.bundleSeqsAligns_strucaligns.equals(other.getBundleSeqsAligns_strucaligns()))) &&
            ((this.bundleSeqsAligns_imports==null && other.getBundleSeqsAligns_imports()==null) || 
             (this.bundleSeqsAligns_imports!=null &&
              this.bundleSeqsAligns_imports.equals(other.getBundleSeqsAligns_imports()))) &&
            ((this.bundleSeqsAligns_styleDictionary==null && other.getBundleSeqsAligns_styleDictionary()==null) || 
             (this.bundleSeqsAligns_styleDictionary!=null &&
              this.bundleSeqsAligns_styleDictionary.equals(other.getBundleSeqsAligns_styleDictionary()))) &&
            ((this.bundleSeqsAligns_userAnnotations==null && other.getBundleSeqsAligns_userAnnotations()==null) || 
             (this.bundleSeqsAligns_userAnnotations!=null &&
              this.bundleSeqsAligns_userAnnotations.equals(other.getBundleSeqsAligns_userAnnotations())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBundleSeqsAligns_sequences() != null) {
            _hashCode += getBundleSeqsAligns_sequences().hashCode();
        }
        if (getBundleSeqsAligns_seqaligns() != null) {
            _hashCode += getBundleSeqsAligns_seqaligns().hashCode();
        }
        if (getBundleSeqsAligns_strucaligns() != null) {
            _hashCode += getBundleSeqsAligns_strucaligns().hashCode();
        }
        if (getBundleSeqsAligns_imports() != null) {
            _hashCode += getBundleSeqsAligns_imports().hashCode();
        }
        if (getBundleSeqsAligns_styleDictionary() != null) {
            _hashCode += getBundleSeqsAligns_styleDictionary().hashCode();
        }
        if (getBundleSeqsAligns_userAnnotations() != null) {
            _hashCode += getBundleSeqsAligns_userAnnotations().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BundleSeqsAlignsType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Bundle-seqs-alignsType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bundleSeqsAligns_sequences");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Bundle-seqs-aligns_sequences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Bundle-seqs-aligns_sequencesType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bundleSeqsAligns_seqaligns");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Bundle-seqs-aligns_seqaligns"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Bundle-seqs-aligns_seqalignsType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bundleSeqsAligns_strucaligns");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Bundle-seqs-aligns_strucaligns"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Bundle-seqs-aligns_strucalignsType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bundleSeqsAligns_imports");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Bundle-seqs-aligns_imports"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Bundle-seqs-aligns_importsType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bundleSeqsAligns_styleDictionary");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Bundle-seqs-aligns_style-dictionary"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Bundle-seqs-aligns_style-dictionaryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bundleSeqsAligns_userAnnotations");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Bundle-seqs-aligns_user-annotations"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Bundle-seqs-aligns_user-annotationsType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
