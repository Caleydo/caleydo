/**
 * Affil_stdType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.ncbi.www.soap.eutils.efetch;

public class Affil_stdType  implements java.io.Serializable {
    private java.lang.String affil_std_affil;

    private java.lang.String affil_std_div;

    private java.lang.String affil_std_city;

    private java.lang.String affil_std_sub;

    private java.lang.String affil_std_country;

    private java.lang.String affil_std_street;

    private java.lang.String affil_std_email;

    private java.lang.String affil_std_fax;

    private java.lang.String affil_std_phone;

    private java.lang.String affil_std_postalCode;

    public Affil_stdType() {
    }

    public Affil_stdType(
           java.lang.String affil_std_affil,
           java.lang.String affil_std_div,
           java.lang.String affil_std_city,
           java.lang.String affil_std_sub,
           java.lang.String affil_std_country,
           java.lang.String affil_std_street,
           java.lang.String affil_std_email,
           java.lang.String affil_std_fax,
           java.lang.String affil_std_phone,
           java.lang.String affil_std_postalCode) {
           this.affil_std_affil = affil_std_affil;
           this.affil_std_div = affil_std_div;
           this.affil_std_city = affil_std_city;
           this.affil_std_sub = affil_std_sub;
           this.affil_std_country = affil_std_country;
           this.affil_std_street = affil_std_street;
           this.affil_std_email = affil_std_email;
           this.affil_std_fax = affil_std_fax;
           this.affil_std_phone = affil_std_phone;
           this.affil_std_postalCode = affil_std_postalCode;
    }


    /**
     * Gets the affil_std_affil value for this Affil_stdType.
     * 
     * @return affil_std_affil
     */
    public java.lang.String getAffil_std_affil() {
        return affil_std_affil;
    }


    /**
     * Sets the affil_std_affil value for this Affil_stdType.
     * 
     * @param affil_std_affil
     */
    public void setAffil_std_affil(java.lang.String affil_std_affil) {
        this.affil_std_affil = affil_std_affil;
    }


    /**
     * Gets the affil_std_div value for this Affil_stdType.
     * 
     * @return affil_std_div
     */
    public java.lang.String getAffil_std_div() {
        return affil_std_div;
    }


    /**
     * Sets the affil_std_div value for this Affil_stdType.
     * 
     * @param affil_std_div
     */
    public void setAffil_std_div(java.lang.String affil_std_div) {
        this.affil_std_div = affil_std_div;
    }


    /**
     * Gets the affil_std_city value for this Affil_stdType.
     * 
     * @return affil_std_city
     */
    public java.lang.String getAffil_std_city() {
        return affil_std_city;
    }


    /**
     * Sets the affil_std_city value for this Affil_stdType.
     * 
     * @param affil_std_city
     */
    public void setAffil_std_city(java.lang.String affil_std_city) {
        this.affil_std_city = affil_std_city;
    }


    /**
     * Gets the affil_std_sub value for this Affil_stdType.
     * 
     * @return affil_std_sub
     */
    public java.lang.String getAffil_std_sub() {
        return affil_std_sub;
    }


    /**
     * Sets the affil_std_sub value for this Affil_stdType.
     * 
     * @param affil_std_sub
     */
    public void setAffil_std_sub(java.lang.String affil_std_sub) {
        this.affil_std_sub = affil_std_sub;
    }


    /**
     * Gets the affil_std_country value for this Affil_stdType.
     * 
     * @return affil_std_country
     */
    public java.lang.String getAffil_std_country() {
        return affil_std_country;
    }


    /**
     * Sets the affil_std_country value for this Affil_stdType.
     * 
     * @param affil_std_country
     */
    public void setAffil_std_country(java.lang.String affil_std_country) {
        this.affil_std_country = affil_std_country;
    }


    /**
     * Gets the affil_std_street value for this Affil_stdType.
     * 
     * @return affil_std_street
     */
    public java.lang.String getAffil_std_street() {
        return affil_std_street;
    }


    /**
     * Sets the affil_std_street value for this Affil_stdType.
     * 
     * @param affil_std_street
     */
    public void setAffil_std_street(java.lang.String affil_std_street) {
        this.affil_std_street = affil_std_street;
    }


    /**
     * Gets the affil_std_email value for this Affil_stdType.
     * 
     * @return affil_std_email
     */
    public java.lang.String getAffil_std_email() {
        return affil_std_email;
    }


    /**
     * Sets the affil_std_email value for this Affil_stdType.
     * 
     * @param affil_std_email
     */
    public void setAffil_std_email(java.lang.String affil_std_email) {
        this.affil_std_email = affil_std_email;
    }


    /**
     * Gets the affil_std_fax value for this Affil_stdType.
     * 
     * @return affil_std_fax
     */
    public java.lang.String getAffil_std_fax() {
        return affil_std_fax;
    }


    /**
     * Sets the affil_std_fax value for this Affil_stdType.
     * 
     * @param affil_std_fax
     */
    public void setAffil_std_fax(java.lang.String affil_std_fax) {
        this.affil_std_fax = affil_std_fax;
    }


    /**
     * Gets the affil_std_phone value for this Affil_stdType.
     * 
     * @return affil_std_phone
     */
    public java.lang.String getAffil_std_phone() {
        return affil_std_phone;
    }


    /**
     * Sets the affil_std_phone value for this Affil_stdType.
     * 
     * @param affil_std_phone
     */
    public void setAffil_std_phone(java.lang.String affil_std_phone) {
        this.affil_std_phone = affil_std_phone;
    }


    /**
     * Gets the affil_std_postalCode value for this Affil_stdType.
     * 
     * @return affil_std_postalCode
     */
    public java.lang.String getAffil_std_postalCode() {
        return affil_std_postalCode;
    }


    /**
     * Sets the affil_std_postalCode value for this Affil_stdType.
     * 
     * @param affil_std_postalCode
     */
    public void setAffil_std_postalCode(java.lang.String affil_std_postalCode) {
        this.affil_std_postalCode = affil_std_postalCode;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Affil_stdType)) return false;
        Affil_stdType other = (Affil_stdType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.affil_std_affil==null && other.getAffil_std_affil()==null) || 
             (this.affil_std_affil!=null &&
              this.affil_std_affil.equals(other.getAffil_std_affil()))) &&
            ((this.affil_std_div==null && other.getAffil_std_div()==null) || 
             (this.affil_std_div!=null &&
              this.affil_std_div.equals(other.getAffil_std_div()))) &&
            ((this.affil_std_city==null && other.getAffil_std_city()==null) || 
             (this.affil_std_city!=null &&
              this.affil_std_city.equals(other.getAffil_std_city()))) &&
            ((this.affil_std_sub==null && other.getAffil_std_sub()==null) || 
             (this.affil_std_sub!=null &&
              this.affil_std_sub.equals(other.getAffil_std_sub()))) &&
            ((this.affil_std_country==null && other.getAffil_std_country()==null) || 
             (this.affil_std_country!=null &&
              this.affil_std_country.equals(other.getAffil_std_country()))) &&
            ((this.affil_std_street==null && other.getAffil_std_street()==null) || 
             (this.affil_std_street!=null &&
              this.affil_std_street.equals(other.getAffil_std_street()))) &&
            ((this.affil_std_email==null && other.getAffil_std_email()==null) || 
             (this.affil_std_email!=null &&
              this.affil_std_email.equals(other.getAffil_std_email()))) &&
            ((this.affil_std_fax==null && other.getAffil_std_fax()==null) || 
             (this.affil_std_fax!=null &&
              this.affil_std_fax.equals(other.getAffil_std_fax()))) &&
            ((this.affil_std_phone==null && other.getAffil_std_phone()==null) || 
             (this.affil_std_phone!=null &&
              this.affil_std_phone.equals(other.getAffil_std_phone()))) &&
            ((this.affil_std_postalCode==null && other.getAffil_std_postalCode()==null) || 
             (this.affil_std_postalCode!=null &&
              this.affil_std_postalCode.equals(other.getAffil_std_postalCode())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAffil_std_affil() != null) {
            _hashCode += getAffil_std_affil().hashCode();
        }
        if (getAffil_std_div() != null) {
            _hashCode += getAffil_std_div().hashCode();
        }
        if (getAffil_std_city() != null) {
            _hashCode += getAffil_std_city().hashCode();
        }
        if (getAffil_std_sub() != null) {
            _hashCode += getAffil_std_sub().hashCode();
        }
        if (getAffil_std_country() != null) {
            _hashCode += getAffil_std_country().hashCode();
        }
        if (getAffil_std_street() != null) {
            _hashCode += getAffil_std_street().hashCode();
        }
        if (getAffil_std_email() != null) {
            _hashCode += getAffil_std_email().hashCode();
        }
        if (getAffil_std_fax() != null) {
            _hashCode += getAffil_std_fax().hashCode();
        }
        if (getAffil_std_phone() != null) {
            _hashCode += getAffil_std_phone().hashCode();
        }
        if (getAffil_std_postalCode() != null) {
            _hashCode += getAffil_std_postalCode().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Affil_stdType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Affil_stdType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("affil_std_affil");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Affil_std_affil"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("affil_std_div");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Affil_std_div"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("affil_std_city");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Affil_std_city"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("affil_std_sub");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Affil_std_sub"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("affil_std_country");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Affil_std_country"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("affil_std_street");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Affil_std_street"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("affil_std_email");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Affil_std_email"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("affil_std_fax");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Affil_std_fax"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("affil_std_phone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Affil_std_phone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("affil_std_postalCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Affil_std_postal-code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
