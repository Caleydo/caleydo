/**
 * BrickType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.ncbi.www.soap.eutils.efetch;

public class BrickType  implements java.io.Serializable {
    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner000Type brick_corner000;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner001Type brick_corner001;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner010Type brick_corner010;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner011Type brick_corner011;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner100Type brick_corner100;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner101Type brick_corner101;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner110Type brick_corner110;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner111Type brick_corner111;

    public BrickType() {
    }

    public BrickType(
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner000Type brick_corner000,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner001Type brick_corner001,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner010Type brick_corner010,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner011Type brick_corner011,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner100Type brick_corner100,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner101Type brick_corner101,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner110Type brick_corner110,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner111Type brick_corner111) {
           this.brick_corner000 = brick_corner000;
           this.brick_corner001 = brick_corner001;
           this.brick_corner010 = brick_corner010;
           this.brick_corner011 = brick_corner011;
           this.brick_corner100 = brick_corner100;
           this.brick_corner101 = brick_corner101;
           this.brick_corner110 = brick_corner110;
           this.brick_corner111 = brick_corner111;
    }


    /**
     * Gets the brick_corner000 value for this BrickType.
     * 
     * @return brick_corner000
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner000Type getBrick_corner000() {
        return brick_corner000;
    }


    /**
     * Sets the brick_corner000 value for this BrickType.
     * 
     * @param brick_corner000
     */
    public void setBrick_corner000(gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner000Type brick_corner000) {
        this.brick_corner000 = brick_corner000;
    }


    /**
     * Gets the brick_corner001 value for this BrickType.
     * 
     * @return brick_corner001
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner001Type getBrick_corner001() {
        return brick_corner001;
    }


    /**
     * Sets the brick_corner001 value for this BrickType.
     * 
     * @param brick_corner001
     */
    public void setBrick_corner001(gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner001Type brick_corner001) {
        this.brick_corner001 = brick_corner001;
    }


    /**
     * Gets the brick_corner010 value for this BrickType.
     * 
     * @return brick_corner010
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner010Type getBrick_corner010() {
        return brick_corner010;
    }


    /**
     * Sets the brick_corner010 value for this BrickType.
     * 
     * @param brick_corner010
     */
    public void setBrick_corner010(gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner010Type brick_corner010) {
        this.brick_corner010 = brick_corner010;
    }


    /**
     * Gets the brick_corner011 value for this BrickType.
     * 
     * @return brick_corner011
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner011Type getBrick_corner011() {
        return brick_corner011;
    }


    /**
     * Sets the brick_corner011 value for this BrickType.
     * 
     * @param brick_corner011
     */
    public void setBrick_corner011(gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner011Type brick_corner011) {
        this.brick_corner011 = brick_corner011;
    }


    /**
     * Gets the brick_corner100 value for this BrickType.
     * 
     * @return brick_corner100
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner100Type getBrick_corner100() {
        return brick_corner100;
    }


    /**
     * Sets the brick_corner100 value for this BrickType.
     * 
     * @param brick_corner100
     */
    public void setBrick_corner100(gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner100Type brick_corner100) {
        this.brick_corner100 = brick_corner100;
    }


    /**
     * Gets the brick_corner101 value for this BrickType.
     * 
     * @return brick_corner101
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner101Type getBrick_corner101() {
        return brick_corner101;
    }


    /**
     * Sets the brick_corner101 value for this BrickType.
     * 
     * @param brick_corner101
     */
    public void setBrick_corner101(gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner101Type brick_corner101) {
        this.brick_corner101 = brick_corner101;
    }


    /**
     * Gets the brick_corner110 value for this BrickType.
     * 
     * @return brick_corner110
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner110Type getBrick_corner110() {
        return brick_corner110;
    }


    /**
     * Sets the brick_corner110 value for this BrickType.
     * 
     * @param brick_corner110
     */
    public void setBrick_corner110(gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner110Type brick_corner110) {
        this.brick_corner110 = brick_corner110;
    }


    /**
     * Gets the brick_corner111 value for this BrickType.
     * 
     * @return brick_corner111
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner111Type getBrick_corner111() {
        return brick_corner111;
    }


    /**
     * Sets the brick_corner111 value for this BrickType.
     * 
     * @param brick_corner111
     */
    public void setBrick_corner111(gov.nih.nlm.ncbi.www.soap.eutils.efetch.Brick_corner111Type brick_corner111) {
        this.brick_corner111 = brick_corner111;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BrickType)) return false;
        BrickType other = (BrickType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.brick_corner000==null && other.getBrick_corner000()==null) || 
             (this.brick_corner000!=null &&
              this.brick_corner000.equals(other.getBrick_corner000()))) &&
            ((this.brick_corner001==null && other.getBrick_corner001()==null) || 
             (this.brick_corner001!=null &&
              this.brick_corner001.equals(other.getBrick_corner001()))) &&
            ((this.brick_corner010==null && other.getBrick_corner010()==null) || 
             (this.brick_corner010!=null &&
              this.brick_corner010.equals(other.getBrick_corner010()))) &&
            ((this.brick_corner011==null && other.getBrick_corner011()==null) || 
             (this.brick_corner011!=null &&
              this.brick_corner011.equals(other.getBrick_corner011()))) &&
            ((this.brick_corner100==null && other.getBrick_corner100()==null) || 
             (this.brick_corner100!=null &&
              this.brick_corner100.equals(other.getBrick_corner100()))) &&
            ((this.brick_corner101==null && other.getBrick_corner101()==null) || 
             (this.brick_corner101!=null &&
              this.brick_corner101.equals(other.getBrick_corner101()))) &&
            ((this.brick_corner110==null && other.getBrick_corner110()==null) || 
             (this.brick_corner110!=null &&
              this.brick_corner110.equals(other.getBrick_corner110()))) &&
            ((this.brick_corner111==null && other.getBrick_corner111()==null) || 
             (this.brick_corner111!=null &&
              this.brick_corner111.equals(other.getBrick_corner111())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBrick_corner000() != null) {
            _hashCode += getBrick_corner000().hashCode();
        }
        if (getBrick_corner001() != null) {
            _hashCode += getBrick_corner001().hashCode();
        }
        if (getBrick_corner010() != null) {
            _hashCode += getBrick_corner010().hashCode();
        }
        if (getBrick_corner011() != null) {
            _hashCode += getBrick_corner011().hashCode();
        }
        if (getBrick_corner100() != null) {
            _hashCode += getBrick_corner100().hashCode();
        }
        if (getBrick_corner101() != null) {
            _hashCode += getBrick_corner101().hashCode();
        }
        if (getBrick_corner110() != null) {
            _hashCode += getBrick_corner110().hashCode();
        }
        if (getBrick_corner111() != null) {
            _hashCode += getBrick_corner111().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BrickType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "BrickType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brick_corner000");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Brick_corner-000"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Brick_corner-000Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brick_corner001");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Brick_corner-001"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Brick_corner-001Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brick_corner010");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Brick_corner-010"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Brick_corner-010Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brick_corner011");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Brick_corner-011"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Brick_corner-011Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brick_corner100");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Brick_corner-100"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Brick_corner-100Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brick_corner101");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Brick_corner-101"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Brick_corner-101Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brick_corner110");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Brick_corner-110"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Brick_corner-110Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brick_corner111");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Brick_corner-111"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Brick_corner-111Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
