/**
 * Atom_elementTypeValue.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.ncbi.www.soap.eutils.efetch;

public class Atom_elementTypeValue implements java.io.Serializable {
    private org.apache.axis.types.NMToken _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected Atom_elementTypeValue(org.apache.axis.types.NMToken value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final org.apache.axis.types.NMToken _h = new org.apache.axis.types.NMToken("h");
    public static final org.apache.axis.types.NMToken _he = new org.apache.axis.types.NMToken("he");
    public static final org.apache.axis.types.NMToken _li = new org.apache.axis.types.NMToken("li");
    public static final org.apache.axis.types.NMToken _be = new org.apache.axis.types.NMToken("be");
    public static final org.apache.axis.types.NMToken _b = new org.apache.axis.types.NMToken("b");
    public static final org.apache.axis.types.NMToken _c = new org.apache.axis.types.NMToken("c");
    public static final org.apache.axis.types.NMToken _n = new org.apache.axis.types.NMToken("n");
    public static final org.apache.axis.types.NMToken _o = new org.apache.axis.types.NMToken("o");
    public static final org.apache.axis.types.NMToken _f = new org.apache.axis.types.NMToken("f");
    public static final org.apache.axis.types.NMToken _ne = new org.apache.axis.types.NMToken("ne");
    public static final org.apache.axis.types.NMToken _na = new org.apache.axis.types.NMToken("na");
    public static final org.apache.axis.types.NMToken _mg = new org.apache.axis.types.NMToken("mg");
    public static final org.apache.axis.types.NMToken _al = new org.apache.axis.types.NMToken("al");
    public static final org.apache.axis.types.NMToken _si = new org.apache.axis.types.NMToken("si");
    public static final org.apache.axis.types.NMToken _p = new org.apache.axis.types.NMToken("p");
    public static final org.apache.axis.types.NMToken _s = new org.apache.axis.types.NMToken("s");
    public static final org.apache.axis.types.NMToken _cl = new org.apache.axis.types.NMToken("cl");
    public static final org.apache.axis.types.NMToken _ar = new org.apache.axis.types.NMToken("ar");
    public static final org.apache.axis.types.NMToken _k = new org.apache.axis.types.NMToken("k");
    public static final org.apache.axis.types.NMToken _ca = new org.apache.axis.types.NMToken("ca");
    public static final org.apache.axis.types.NMToken _sc = new org.apache.axis.types.NMToken("sc");
    public static final org.apache.axis.types.NMToken _ti = new org.apache.axis.types.NMToken("ti");
    public static final org.apache.axis.types.NMToken _v = new org.apache.axis.types.NMToken("v");
    public static final org.apache.axis.types.NMToken _cr = new org.apache.axis.types.NMToken("cr");
    public static final org.apache.axis.types.NMToken _mn = new org.apache.axis.types.NMToken("mn");
    public static final org.apache.axis.types.NMToken _fe = new org.apache.axis.types.NMToken("fe");
    public static final org.apache.axis.types.NMToken _co = new org.apache.axis.types.NMToken("co");
    public static final org.apache.axis.types.NMToken _ni = new org.apache.axis.types.NMToken("ni");
    public static final org.apache.axis.types.NMToken _cu = new org.apache.axis.types.NMToken("cu");
    public static final org.apache.axis.types.NMToken _zn = new org.apache.axis.types.NMToken("zn");
    public static final org.apache.axis.types.NMToken _ga = new org.apache.axis.types.NMToken("ga");
    public static final org.apache.axis.types.NMToken _ge = new org.apache.axis.types.NMToken("ge");
    public static final org.apache.axis.types.NMToken _as = new org.apache.axis.types.NMToken("as");
    public static final org.apache.axis.types.NMToken _se = new org.apache.axis.types.NMToken("se");
    public static final org.apache.axis.types.NMToken _br = new org.apache.axis.types.NMToken("br");
    public static final org.apache.axis.types.NMToken _kr = new org.apache.axis.types.NMToken("kr");
    public static final org.apache.axis.types.NMToken _rb = new org.apache.axis.types.NMToken("rb");
    public static final org.apache.axis.types.NMToken _sr = new org.apache.axis.types.NMToken("sr");
    public static final org.apache.axis.types.NMToken _y = new org.apache.axis.types.NMToken("y");
    public static final org.apache.axis.types.NMToken _zr = new org.apache.axis.types.NMToken("zr");
    public static final org.apache.axis.types.NMToken _nb = new org.apache.axis.types.NMToken("nb");
    public static final org.apache.axis.types.NMToken _mo = new org.apache.axis.types.NMToken("mo");
    public static final org.apache.axis.types.NMToken _tc = new org.apache.axis.types.NMToken("tc");
    public static final org.apache.axis.types.NMToken _ru = new org.apache.axis.types.NMToken("ru");
    public static final org.apache.axis.types.NMToken _rh = new org.apache.axis.types.NMToken("rh");
    public static final org.apache.axis.types.NMToken _pd = new org.apache.axis.types.NMToken("pd");
    public static final org.apache.axis.types.NMToken _ag = new org.apache.axis.types.NMToken("ag");
    public static final org.apache.axis.types.NMToken _cd = new org.apache.axis.types.NMToken("cd");
    public static final org.apache.axis.types.NMToken _in = new org.apache.axis.types.NMToken("in");
    public static final org.apache.axis.types.NMToken _sn = new org.apache.axis.types.NMToken("sn");
    public static final org.apache.axis.types.NMToken _sb = new org.apache.axis.types.NMToken("sb");
    public static final org.apache.axis.types.NMToken _te = new org.apache.axis.types.NMToken("te");
    public static final org.apache.axis.types.NMToken _i = new org.apache.axis.types.NMToken("i");
    public static final org.apache.axis.types.NMToken _xe = new org.apache.axis.types.NMToken("xe");
    public static final org.apache.axis.types.NMToken _cs = new org.apache.axis.types.NMToken("cs");
    public static final org.apache.axis.types.NMToken _ba = new org.apache.axis.types.NMToken("ba");
    public static final org.apache.axis.types.NMToken _la = new org.apache.axis.types.NMToken("la");
    public static final org.apache.axis.types.NMToken _ce = new org.apache.axis.types.NMToken("ce");
    public static final org.apache.axis.types.NMToken _pr = new org.apache.axis.types.NMToken("pr");
    public static final org.apache.axis.types.NMToken _nd = new org.apache.axis.types.NMToken("nd");
    public static final org.apache.axis.types.NMToken _pm = new org.apache.axis.types.NMToken("pm");
    public static final org.apache.axis.types.NMToken _sm = new org.apache.axis.types.NMToken("sm");
    public static final org.apache.axis.types.NMToken _eu = new org.apache.axis.types.NMToken("eu");
    public static final org.apache.axis.types.NMToken _gd = new org.apache.axis.types.NMToken("gd");
    public static final org.apache.axis.types.NMToken _tb = new org.apache.axis.types.NMToken("tb");
    public static final org.apache.axis.types.NMToken _dy = new org.apache.axis.types.NMToken("dy");
    public static final org.apache.axis.types.NMToken _ho = new org.apache.axis.types.NMToken("ho");
    public static final org.apache.axis.types.NMToken _er = new org.apache.axis.types.NMToken("er");
    public static final org.apache.axis.types.NMToken _tm = new org.apache.axis.types.NMToken("tm");
    public static final org.apache.axis.types.NMToken _yb = new org.apache.axis.types.NMToken("yb");
    public static final org.apache.axis.types.NMToken _lu = new org.apache.axis.types.NMToken("lu");
    public static final org.apache.axis.types.NMToken _hf = new org.apache.axis.types.NMToken("hf");
    public static final org.apache.axis.types.NMToken _ta = new org.apache.axis.types.NMToken("ta");
    public static final org.apache.axis.types.NMToken _w = new org.apache.axis.types.NMToken("w");
    public static final org.apache.axis.types.NMToken _re = new org.apache.axis.types.NMToken("re");
    public static final org.apache.axis.types.NMToken _os = new org.apache.axis.types.NMToken("os");
    public static final org.apache.axis.types.NMToken _ir = new org.apache.axis.types.NMToken("ir");
    public static final org.apache.axis.types.NMToken _pt = new org.apache.axis.types.NMToken("pt");
    public static final org.apache.axis.types.NMToken _au = new org.apache.axis.types.NMToken("au");
    public static final org.apache.axis.types.NMToken _hg = new org.apache.axis.types.NMToken("hg");
    public static final org.apache.axis.types.NMToken _tl = new org.apache.axis.types.NMToken("tl");
    public static final org.apache.axis.types.NMToken _pb = new org.apache.axis.types.NMToken("pb");
    public static final org.apache.axis.types.NMToken _bi = new org.apache.axis.types.NMToken("bi");
    public static final org.apache.axis.types.NMToken _po = new org.apache.axis.types.NMToken("po");
    public static final org.apache.axis.types.NMToken _at = new org.apache.axis.types.NMToken("at");
    public static final org.apache.axis.types.NMToken _rn = new org.apache.axis.types.NMToken("rn");
    public static final org.apache.axis.types.NMToken _fr = new org.apache.axis.types.NMToken("fr");
    public static final org.apache.axis.types.NMToken _ra = new org.apache.axis.types.NMToken("ra");
    public static final org.apache.axis.types.NMToken _ac = new org.apache.axis.types.NMToken("ac");
    public static final org.apache.axis.types.NMToken _th = new org.apache.axis.types.NMToken("th");
    public static final org.apache.axis.types.NMToken _pa = new org.apache.axis.types.NMToken("pa");
    public static final org.apache.axis.types.NMToken _u = new org.apache.axis.types.NMToken("u");
    public static final org.apache.axis.types.NMToken _np = new org.apache.axis.types.NMToken("np");
    public static final org.apache.axis.types.NMToken _pu = new org.apache.axis.types.NMToken("pu");
    public static final org.apache.axis.types.NMToken _am = new org.apache.axis.types.NMToken("am");
    public static final org.apache.axis.types.NMToken _cm = new org.apache.axis.types.NMToken("cm");
    public static final org.apache.axis.types.NMToken _bk = new org.apache.axis.types.NMToken("bk");
    public static final org.apache.axis.types.NMToken _cf = new org.apache.axis.types.NMToken("cf");
    public static final org.apache.axis.types.NMToken _es = new org.apache.axis.types.NMToken("es");
    public static final org.apache.axis.types.NMToken _fm = new org.apache.axis.types.NMToken("fm");
    public static final org.apache.axis.types.NMToken _md = new org.apache.axis.types.NMToken("md");
    public static final org.apache.axis.types.NMToken _no = new org.apache.axis.types.NMToken("no");
    public static final org.apache.axis.types.NMToken _lr = new org.apache.axis.types.NMToken("lr");
    public static final org.apache.axis.types.NMToken _other = new org.apache.axis.types.NMToken("other");
    public static final org.apache.axis.types.NMToken _unknown = new org.apache.axis.types.NMToken("unknown");
    public static final Atom_elementTypeValue h = new Atom_elementTypeValue(_h);
    public static final Atom_elementTypeValue he = new Atom_elementTypeValue(_he);
    public static final Atom_elementTypeValue li = new Atom_elementTypeValue(_li);
    public static final Atom_elementTypeValue be = new Atom_elementTypeValue(_be);
    public static final Atom_elementTypeValue b = new Atom_elementTypeValue(_b);
    public static final Atom_elementTypeValue c = new Atom_elementTypeValue(_c);
    public static final Atom_elementTypeValue n = new Atom_elementTypeValue(_n);
    public static final Atom_elementTypeValue o = new Atom_elementTypeValue(_o);
    public static final Atom_elementTypeValue f = new Atom_elementTypeValue(_f);
    public static final Atom_elementTypeValue ne = new Atom_elementTypeValue(_ne);
    public static final Atom_elementTypeValue na = new Atom_elementTypeValue(_na);
    public static final Atom_elementTypeValue mg = new Atom_elementTypeValue(_mg);
    public static final Atom_elementTypeValue al = new Atom_elementTypeValue(_al);
    public static final Atom_elementTypeValue si = new Atom_elementTypeValue(_si);
    public static final Atom_elementTypeValue p = new Atom_elementTypeValue(_p);
    public static final Atom_elementTypeValue s = new Atom_elementTypeValue(_s);
    public static final Atom_elementTypeValue cl = new Atom_elementTypeValue(_cl);
    public static final Atom_elementTypeValue ar = new Atom_elementTypeValue(_ar);
    public static final Atom_elementTypeValue k = new Atom_elementTypeValue(_k);
    public static final Atom_elementTypeValue ca = new Atom_elementTypeValue(_ca);
    public static final Atom_elementTypeValue sc = new Atom_elementTypeValue(_sc);
    public static final Atom_elementTypeValue ti = new Atom_elementTypeValue(_ti);
    public static final Atom_elementTypeValue v = new Atom_elementTypeValue(_v);
    public static final Atom_elementTypeValue cr = new Atom_elementTypeValue(_cr);
    public static final Atom_elementTypeValue mn = new Atom_elementTypeValue(_mn);
    public static final Atom_elementTypeValue fe = new Atom_elementTypeValue(_fe);
    public static final Atom_elementTypeValue co = new Atom_elementTypeValue(_co);
    public static final Atom_elementTypeValue ni = new Atom_elementTypeValue(_ni);
    public static final Atom_elementTypeValue cu = new Atom_elementTypeValue(_cu);
    public static final Atom_elementTypeValue zn = new Atom_elementTypeValue(_zn);
    public static final Atom_elementTypeValue ga = new Atom_elementTypeValue(_ga);
    public static final Atom_elementTypeValue ge = new Atom_elementTypeValue(_ge);
    public static final Atom_elementTypeValue as = new Atom_elementTypeValue(_as);
    public static final Atom_elementTypeValue se = new Atom_elementTypeValue(_se);
    public static final Atom_elementTypeValue br = new Atom_elementTypeValue(_br);
    public static final Atom_elementTypeValue kr = new Atom_elementTypeValue(_kr);
    public static final Atom_elementTypeValue rb = new Atom_elementTypeValue(_rb);
    public static final Atom_elementTypeValue sr = new Atom_elementTypeValue(_sr);
    public static final Atom_elementTypeValue y = new Atom_elementTypeValue(_y);
    public static final Atom_elementTypeValue zr = new Atom_elementTypeValue(_zr);
    public static final Atom_elementTypeValue nb = new Atom_elementTypeValue(_nb);
    public static final Atom_elementTypeValue mo = new Atom_elementTypeValue(_mo);
    public static final Atom_elementTypeValue tc = new Atom_elementTypeValue(_tc);
    public static final Atom_elementTypeValue ru = new Atom_elementTypeValue(_ru);
    public static final Atom_elementTypeValue rh = new Atom_elementTypeValue(_rh);
    public static final Atom_elementTypeValue pd = new Atom_elementTypeValue(_pd);
    public static final Atom_elementTypeValue ag = new Atom_elementTypeValue(_ag);
    public static final Atom_elementTypeValue cd = new Atom_elementTypeValue(_cd);
    public static final Atom_elementTypeValue in = new Atom_elementTypeValue(_in);
    public static final Atom_elementTypeValue sn = new Atom_elementTypeValue(_sn);
    public static final Atom_elementTypeValue sb = new Atom_elementTypeValue(_sb);
    public static final Atom_elementTypeValue te = new Atom_elementTypeValue(_te);
    public static final Atom_elementTypeValue i = new Atom_elementTypeValue(_i);
    public static final Atom_elementTypeValue xe = new Atom_elementTypeValue(_xe);
    public static final Atom_elementTypeValue cs = new Atom_elementTypeValue(_cs);
    public static final Atom_elementTypeValue ba = new Atom_elementTypeValue(_ba);
    public static final Atom_elementTypeValue la = new Atom_elementTypeValue(_la);
    public static final Atom_elementTypeValue ce = new Atom_elementTypeValue(_ce);
    public static final Atom_elementTypeValue pr = new Atom_elementTypeValue(_pr);
    public static final Atom_elementTypeValue nd = new Atom_elementTypeValue(_nd);
    public static final Atom_elementTypeValue pm = new Atom_elementTypeValue(_pm);
    public static final Atom_elementTypeValue sm = new Atom_elementTypeValue(_sm);
    public static final Atom_elementTypeValue eu = new Atom_elementTypeValue(_eu);
    public static final Atom_elementTypeValue gd = new Atom_elementTypeValue(_gd);
    public static final Atom_elementTypeValue tb = new Atom_elementTypeValue(_tb);
    public static final Atom_elementTypeValue dy = new Atom_elementTypeValue(_dy);
    public static final Atom_elementTypeValue ho = new Atom_elementTypeValue(_ho);
    public static final Atom_elementTypeValue er = new Atom_elementTypeValue(_er);
    public static final Atom_elementTypeValue tm = new Atom_elementTypeValue(_tm);
    public static final Atom_elementTypeValue yb = new Atom_elementTypeValue(_yb);
    public static final Atom_elementTypeValue lu = new Atom_elementTypeValue(_lu);
    public static final Atom_elementTypeValue hf = new Atom_elementTypeValue(_hf);
    public static final Atom_elementTypeValue ta = new Atom_elementTypeValue(_ta);
    public static final Atom_elementTypeValue w = new Atom_elementTypeValue(_w);
    public static final Atom_elementTypeValue re = new Atom_elementTypeValue(_re);
    public static final Atom_elementTypeValue os = new Atom_elementTypeValue(_os);
    public static final Atom_elementTypeValue ir = new Atom_elementTypeValue(_ir);
    public static final Atom_elementTypeValue pt = new Atom_elementTypeValue(_pt);
    public static final Atom_elementTypeValue au = new Atom_elementTypeValue(_au);
    public static final Atom_elementTypeValue hg = new Atom_elementTypeValue(_hg);
    public static final Atom_elementTypeValue tl = new Atom_elementTypeValue(_tl);
    public static final Atom_elementTypeValue pb = new Atom_elementTypeValue(_pb);
    public static final Atom_elementTypeValue bi = new Atom_elementTypeValue(_bi);
    public static final Atom_elementTypeValue po = new Atom_elementTypeValue(_po);
    public static final Atom_elementTypeValue at = new Atom_elementTypeValue(_at);
    public static final Atom_elementTypeValue rn = new Atom_elementTypeValue(_rn);
    public static final Atom_elementTypeValue fr = new Atom_elementTypeValue(_fr);
    public static final Atom_elementTypeValue ra = new Atom_elementTypeValue(_ra);
    public static final Atom_elementTypeValue ac = new Atom_elementTypeValue(_ac);
    public static final Atom_elementTypeValue th = new Atom_elementTypeValue(_th);
    public static final Atom_elementTypeValue pa = new Atom_elementTypeValue(_pa);
    public static final Atom_elementTypeValue u = new Atom_elementTypeValue(_u);
    public static final Atom_elementTypeValue np = new Atom_elementTypeValue(_np);
    public static final Atom_elementTypeValue pu = new Atom_elementTypeValue(_pu);
    public static final Atom_elementTypeValue am = new Atom_elementTypeValue(_am);
    public static final Atom_elementTypeValue cm = new Atom_elementTypeValue(_cm);
    public static final Atom_elementTypeValue bk = new Atom_elementTypeValue(_bk);
    public static final Atom_elementTypeValue cf = new Atom_elementTypeValue(_cf);
    public static final Atom_elementTypeValue es = new Atom_elementTypeValue(_es);
    public static final Atom_elementTypeValue fm = new Atom_elementTypeValue(_fm);
    public static final Atom_elementTypeValue md = new Atom_elementTypeValue(_md);
    public static final Atom_elementTypeValue no = new Atom_elementTypeValue(_no);
    public static final Atom_elementTypeValue lr = new Atom_elementTypeValue(_lr);
    public static final Atom_elementTypeValue other = new Atom_elementTypeValue(_other);
    public static final Atom_elementTypeValue unknown = new Atom_elementTypeValue(_unknown);
    public org.apache.axis.types.NMToken getValue() { return _value_;}
    public static Atom_elementTypeValue fromValue(org.apache.axis.types.NMToken value)
          throws java.lang.IllegalArgumentException {
        Atom_elementTypeValue enumeration = (Atom_elementTypeValue)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static Atom_elementTypeValue fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        try {
            return fromValue(new org.apache.axis.types.NMToken(value));
        } catch (Exception e) {
            throw new java.lang.IllegalArgumentException();
        }
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_.toString();}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Atom_elementTypeValue.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", ">Atom_elementType>value"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
