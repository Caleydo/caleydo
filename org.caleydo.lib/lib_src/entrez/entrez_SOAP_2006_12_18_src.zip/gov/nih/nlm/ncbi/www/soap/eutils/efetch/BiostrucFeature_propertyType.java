/**
 * BiostrucFeature_propertyType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.ncbi.www.soap.eutils.efetch;

public class BiostrucFeature_propertyType  implements java.io.Serializable {
    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_colorType biostrucFeature_property_color;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_renderType biostrucFeature_property_render;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_transformType biostrucFeature_property_transform;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_cameraType biostrucFeature_property_camera;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_scriptType biostrucFeature_property_script;

    private gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_userType biostrucFeature_property_user;

    public BiostrucFeature_propertyType() {
    }

    public BiostrucFeature_propertyType(
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_colorType biostrucFeature_property_color,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_renderType biostrucFeature_property_render,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_transformType biostrucFeature_property_transform,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_cameraType biostrucFeature_property_camera,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_scriptType biostrucFeature_property_script,
           gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_userType biostrucFeature_property_user) {
           this.biostrucFeature_property_color = biostrucFeature_property_color;
           this.biostrucFeature_property_render = biostrucFeature_property_render;
           this.biostrucFeature_property_transform = biostrucFeature_property_transform;
           this.biostrucFeature_property_camera = biostrucFeature_property_camera;
           this.biostrucFeature_property_script = biostrucFeature_property_script;
           this.biostrucFeature_property_user = biostrucFeature_property_user;
    }


    /**
     * Gets the biostrucFeature_property_color value for this BiostrucFeature_propertyType.
     * 
     * @return biostrucFeature_property_color
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_colorType getBiostrucFeature_property_color() {
        return biostrucFeature_property_color;
    }


    /**
     * Sets the biostrucFeature_property_color value for this BiostrucFeature_propertyType.
     * 
     * @param biostrucFeature_property_color
     */
    public void setBiostrucFeature_property_color(gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_colorType biostrucFeature_property_color) {
        this.biostrucFeature_property_color = biostrucFeature_property_color;
    }


    /**
     * Gets the biostrucFeature_property_render value for this BiostrucFeature_propertyType.
     * 
     * @return biostrucFeature_property_render
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_renderType getBiostrucFeature_property_render() {
        return biostrucFeature_property_render;
    }


    /**
     * Sets the biostrucFeature_property_render value for this BiostrucFeature_propertyType.
     * 
     * @param biostrucFeature_property_render
     */
    public void setBiostrucFeature_property_render(gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_renderType biostrucFeature_property_render) {
        this.biostrucFeature_property_render = biostrucFeature_property_render;
    }


    /**
     * Gets the biostrucFeature_property_transform value for this BiostrucFeature_propertyType.
     * 
     * @return biostrucFeature_property_transform
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_transformType getBiostrucFeature_property_transform() {
        return biostrucFeature_property_transform;
    }


    /**
     * Sets the biostrucFeature_property_transform value for this BiostrucFeature_propertyType.
     * 
     * @param biostrucFeature_property_transform
     */
    public void setBiostrucFeature_property_transform(gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_transformType biostrucFeature_property_transform) {
        this.biostrucFeature_property_transform = biostrucFeature_property_transform;
    }


    /**
     * Gets the biostrucFeature_property_camera value for this BiostrucFeature_propertyType.
     * 
     * @return biostrucFeature_property_camera
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_cameraType getBiostrucFeature_property_camera() {
        return biostrucFeature_property_camera;
    }


    /**
     * Sets the biostrucFeature_property_camera value for this BiostrucFeature_propertyType.
     * 
     * @param biostrucFeature_property_camera
     */
    public void setBiostrucFeature_property_camera(gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_cameraType biostrucFeature_property_camera) {
        this.biostrucFeature_property_camera = biostrucFeature_property_camera;
    }


    /**
     * Gets the biostrucFeature_property_script value for this BiostrucFeature_propertyType.
     * 
     * @return biostrucFeature_property_script
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_scriptType getBiostrucFeature_property_script() {
        return biostrucFeature_property_script;
    }


    /**
     * Sets the biostrucFeature_property_script value for this BiostrucFeature_propertyType.
     * 
     * @param biostrucFeature_property_script
     */
    public void setBiostrucFeature_property_script(gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_scriptType biostrucFeature_property_script) {
        this.biostrucFeature_property_script = biostrucFeature_property_script;
    }


    /**
     * Gets the biostrucFeature_property_user value for this BiostrucFeature_propertyType.
     * 
     * @return biostrucFeature_property_user
     */
    public gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_userType getBiostrucFeature_property_user() {
        return biostrucFeature_property_user;
    }


    /**
     * Sets the biostrucFeature_property_user value for this BiostrucFeature_propertyType.
     * 
     * @param biostrucFeature_property_user
     */
    public void setBiostrucFeature_property_user(gov.nih.nlm.ncbi.www.soap.eutils.efetch.BiostrucFeature_property_userType biostrucFeature_property_user) {
        this.biostrucFeature_property_user = biostrucFeature_property_user;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BiostrucFeature_propertyType)) return false;
        BiostrucFeature_propertyType other = (BiostrucFeature_propertyType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.biostrucFeature_property_color==null && other.getBiostrucFeature_property_color()==null) || 
             (this.biostrucFeature_property_color!=null &&
              this.biostrucFeature_property_color.equals(other.getBiostrucFeature_property_color()))) &&
            ((this.biostrucFeature_property_render==null && other.getBiostrucFeature_property_render()==null) || 
             (this.biostrucFeature_property_render!=null &&
              this.biostrucFeature_property_render.equals(other.getBiostrucFeature_property_render()))) &&
            ((this.biostrucFeature_property_transform==null && other.getBiostrucFeature_property_transform()==null) || 
             (this.biostrucFeature_property_transform!=null &&
              this.biostrucFeature_property_transform.equals(other.getBiostrucFeature_property_transform()))) &&
            ((this.biostrucFeature_property_camera==null && other.getBiostrucFeature_property_camera()==null) || 
             (this.biostrucFeature_property_camera!=null &&
              this.biostrucFeature_property_camera.equals(other.getBiostrucFeature_property_camera()))) &&
            ((this.biostrucFeature_property_script==null && other.getBiostrucFeature_property_script()==null) || 
             (this.biostrucFeature_property_script!=null &&
              this.biostrucFeature_property_script.equals(other.getBiostrucFeature_property_script()))) &&
            ((this.biostrucFeature_property_user==null && other.getBiostrucFeature_property_user()==null) || 
             (this.biostrucFeature_property_user!=null &&
              this.biostrucFeature_property_user.equals(other.getBiostrucFeature_property_user())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBiostrucFeature_property_color() != null) {
            _hashCode += getBiostrucFeature_property_color().hashCode();
        }
        if (getBiostrucFeature_property_render() != null) {
            _hashCode += getBiostrucFeature_property_render().hashCode();
        }
        if (getBiostrucFeature_property_transform() != null) {
            _hashCode += getBiostrucFeature_property_transform().hashCode();
        }
        if (getBiostrucFeature_property_camera() != null) {
            _hashCode += getBiostrucFeature_property_camera().hashCode();
        }
        if (getBiostrucFeature_property_script() != null) {
            _hashCode += getBiostrucFeature_property_script().hashCode();
        }
        if (getBiostrucFeature_property_user() != null) {
            _hashCode += getBiostrucFeature_property_user().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BiostrucFeature_propertyType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Biostruc-feature_propertyType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("biostrucFeature_property_color");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Biostruc-feature_property_color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Biostruc-feature_property_colorType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("biostrucFeature_property_render");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Biostruc-feature_property_render"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Biostruc-feature_property_renderType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("biostrucFeature_property_transform");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Biostruc-feature_property_transform"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Biostruc-feature_property_transformType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("biostrucFeature_property_camera");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Biostruc-feature_property_camera"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Biostruc-feature_property_cameraType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("biostrucFeature_property_script");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Biostruc-feature_property_script"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Biostruc-feature_property_scriptType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("biostrucFeature_property_user");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Biostruc-feature_property_user"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ncbi.nlm.nih.gov/soap/eutils/efetch", "Biostruc-feature_property_userType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
