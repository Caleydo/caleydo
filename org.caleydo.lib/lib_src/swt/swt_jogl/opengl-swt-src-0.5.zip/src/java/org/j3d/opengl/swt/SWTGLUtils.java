/*****************************************************************************
 *                     Yumetech, Inc Copyright (c) 2005
 *                               Java Source
 *
 * This source is licensed under the BSD-style License
 * Please read http://www.opensource.org/licenses/bsd-license.php for more
 * information or docs/BSD.txt in the downloaded code.
 *
 * This software comes with the standard NO WARRANTY disclaimer for any
 * purpose. Use it at your own risk. If there's a problem you get to fix it.
 *
 ****************************************************************************/

package org.j3d.opengl.swt;

// External imports
import javax.media.opengl.GLCapabilities;

import org.eclipse.swt.opengl.GLData;

// Local imports
// None

/**
 * Utility class for swapping between the stock SWT GL classes and our own.
 *
 * @author Justin Couch
 * @version $Revision: 1.1 $
 */
public class SWTGLUtils
{
    /** Error when passed a null GLData */
    private static final String NULL_GLDATA_ERR =
        "Null SWT GLData reference provided.";

    /** Error when passed a null GLCapabilties */
    private static final String NULL_GLCAPS_ERR =
        "Null GLCapabilities reference provided.";

    /**
     * Private constructor to prevent direct instantiation.
     */
    SWTGLUtils()
    {
    }

    /**
     * Convert a SWT GLData into a GLCapabilties object. When converting, the
     * offscreen render to texture values are left as default.
     *
     * @param swtData the source data to pull values from
     * @return A new GLCapabilities instance to use
     * @throws NullPointerException The swtData instance was null
     */
    public static GLCapabilities toGLCapabilities(GLData swtData)
    {
        if(swtData == null)
            throw new NullPointerException(NULL_GLDATA_ERR);

        GLCapabilities ret_val = new GLCapabilities();
        ret_val.setDoubleBuffered(swtData.doubleBuffer);
        ret_val.setStereo(swtData.stereo);
        ret_val.setRedBits(swtData.redSize);
        ret_val.setGreenBits(swtData.greenSize);
        ret_val.setBlueBits(swtData.blueSize);
        ret_val.setAlphaBits(swtData.alphaSize);
        ret_val.setDepthBits(swtData.depthSize);
        ret_val.setStencilBits(swtData.stencilSize);
        ret_val.setAccumRedBits(swtData.accumRedSize);
        ret_val.setAccumGreenBits(swtData.accumGreenSize);
        ret_val.setAccumBlueBits(swtData.accumBlueSize);
        ret_val.setAccumAlphaBits(swtData.accumAlphaSize);
        ret_val.setSampleBuffers(swtData.sampleBuffers != 0);
        ret_val.setNumSamples(swtData.samples);

        return ret_val;
    }

    /**
     * Convert from a GLCapabilities to a SWT GLData object.
     *
     * @param caps The capabilities to copy
     * @return A new GLData instance
     */
    public static GLData toGLData(GLCapabilities caps)
    {
        if(caps == null)
            throw new NullPointerException(NULL_GLCAPS_ERR);

        GLData ret_val = new GLData();
        ret_val.doubleBuffer = caps.getDoubleBuffered();
        ret_val.stereo = caps.getStereo();
        ret_val.redSize = caps.getRedBits();
        ret_val.greenSize = caps.getGreenBits();
        ret_val.blueSize = caps.getBlueBits();
        ret_val.alphaSize = caps.getAlphaBits();
        ret_val.depthSize = caps.getDepthBits();
        ret_val.stencilSize = caps.getStencilBits();
        ret_val.accumRedSize = caps.getAccumRedBits();
        ret_val.accumGreenSize = caps.getAccumGreenBits();
        ret_val.accumBlueSize = caps.getAccumBlueBits();
        ret_val.accumAlphaSize = caps.getAccumAlphaBits();
        ret_val.sampleBuffers = caps.getSampleBuffers() ? 1 : 0;
        ret_val.samples = caps.getNumSamples();

        return ret_val;
    }
}
