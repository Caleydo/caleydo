/*****************************************************************************
 *                                                                                 Yumetech, Inc Copyright (c) 2005
 *                                                                                                                         Java Source
 *
 * This source is licensed under the BSD-style License
 * Please read http://www.opensource.org/licenses/bsd-license.php for more
 * information or docs/BSD.txt in the downloaded code.
 *
 * This software comes with the standard NO WARRANTY disclaimer for any
 * purpose. Use it at your own risk. If there's a problem you get to fix it.
 *
 ****************************************************************************/

package org.j3d.opengl.swt.internal.ri.osx;

// External imports
import javax.media.opengl.*;
import com.sun.opengl.impl.*;

// Local imports
// None

/**
 * Base class for the GLDrawable implementations on OSX under AGL/SWT.
 *
 * @author Justin Couch
 * @version $Revision: 1.1 $
 */
public abstract class MacGLDrawable extends GLDrawableImpl
{
    protected static final boolean DEBUG = Debug.debug("MacGLDrawable");

    /** The carbon window we're part of */
    protected int carbonWindow;

    /** The carbon window's port */
    protected int carbonPort;

    protected GLCapabilities capabilities;
    protected GLCapabilitiesChooser chooser;

    public MacGLDrawable(GLCapabilities capabilities,
                         GLCapabilitiesChooser chooser)
    {
        this.capabilities = (GLCapabilities) capabilities.clone();
        this.chooser = chooser;
    }

    public void setRealized(boolean val)
    {
        throw new GLException("Should not call this (should only be called for onscreen GLDrawables)");
    }

    public void destroy()
    {
        throw new GLException("Should not call this (should only be called for offscreen GLDrawables)");
    }

    public void swapBuffers() throws GLException
    {
    }

    public GLCapabilities getCapabilities()
    {
        int numFormats = 1;
        GLCapabilities availableCaps[] = new GLCapabilities[numFormats];
        availableCaps[0] = capabilities;
        int pixelFormat = chooser.chooseCapabilities(capabilities, availableCaps, 0);
        if((pixelFormat < 0) || (pixelFormat >= numFormats))
        {
            throw new GLException("Invalid result " + pixelFormat +
                                  " from GLCapabilitiesChooser (should be between 0 and " +
                                  (numFormats - 1) + ")");
        }

        if(DEBUG)
        {
            System.err.println(getThreadName() + ": Chosen pixel format (" + pixelFormat + "):");
            System.err.println(availableCaps[pixelFormat]);
        }

        return availableCaps[pixelFormat];
    }

    public long getCarbonWindow()
    {
        return carbonWindow;
    }

    public long getCarbonPort()
    {
        return carbonPort;
    }

    protected static String getThreadName()
    {
        return Thread.currentThread().getName();
    }
}
