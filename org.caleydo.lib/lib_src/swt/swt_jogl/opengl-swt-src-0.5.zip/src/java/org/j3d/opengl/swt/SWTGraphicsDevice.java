/*****************************************************************************
 *                     Yumetech, Inc Copyright (c) 2005
 *                               Java Source
 *
 * This source is licensed under the BSD-style License
 * Please read http://www.opensource.org/licenses/bsd-license.php for more
 * information or docs/BSD.txt in the downloaded code.
 *
 * This software comes with the standard NO WARRANTY disclaimer for any
 * purpose. Use it at your own risk. If there's a problem you get to fix it.
 *
 ****************************************************************************/

package org.j3d.opengl.swt;

// External imports
import javax.media.opengl.AbstractGraphicsDevice;

// Local imports
// None

/**
 * A wrapper for an AWT GraphicsConfiguration allowing it to be
 * handled in a toolkit-independent manner.
 *
 * @author Justin Couch
 * @version $Revision: 1.3 $
 */
public class SWTGraphicsDevice implements AbstractGraphicsDevice
{
    /**
     * Create a new isntance of this graphics device that wraps the
     * given SWT-specific information in a platform independent way.
     */
    public SWTGraphicsDevice()
    {
    }
}
