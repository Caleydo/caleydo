/*****************************************************************************
 *                     Yumetech, Inc Copyright (c) 2005
 *                               Java Source
 *
 * This source is licensed under the BSD-style License
 * Please read http://www.opensource.org/licenses/bsd-license.php for more
 * information or docs/BSD.txt in the downloaded code.
 *
 * This software comes with the standard NO WARRANTY disclaimer for any
 * purpose. Use it at your own risk. If there's a problem you get to fix it.
 *
 ****************************************************************************/

package org.j3d.opengl.swt.internal.ri.x11;

// External imports
import javax.media.opengl.GLContext;
import javax.media.opengl.GLException;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;

import org.eclipse.swt.internal.gtk.OS;

import com.sun.opengl.impl.x11.GLX;

// Local imports
import org.j3d.opengl.swt.internal.ri.SurfaceController;

/**
 * An implementation of the {@link X11GLDrawable} that works with SWT
 * based implementations.
 * <p>
 *
 * @author Justin Couch
 * @version $Revision: 1.1 $
 */
public class X11OnscreenGLDrawable extends X11GLDrawable
    implements SurfaceController
{
    /** The component that this drawable is wrapping */
    private Composite component;

    /** Set the realisation state */
    private boolean realized;

    public X11OnscreenGLDrawable(Composite component)
    {
        super(null, null);

        this.component = component;
    }

    //---------------------------------------------------------------
    // Methods defined by GLDrawable
    //---------------------------------------------------------------

    /**
     * Create a new context instance that may share data with the given
     * context.
     *
     * @param sharedWith The context instance to share, or null if not shared
     */
    public GLContext createContext(GLContext shareWith) {
        return new X11OnscreenGLContext(this, this, shareWith);
    }

    /**
     * Indicates to on-screen GLDrawable implementations whether the underlying
     * window has been created and can be drawn into.
     *
     * @param state true when this has been realised by the canvas
     * @see GLDrawable#setRealized
     */
    public void setRealized(boolean realized)
    {
        this.realized = realized;
    }

    /**
     * Requests a new width and height for this drawable.
     *
     * @param width The new width of the drawable
     * @param height The new height of the drawable
     */
    public void setSize(int width, int height)
    {
        component.setSize(width, height);
    }

    /**
     * Get the current width of the drawable in pixels.
     *
     * @return A value greater than or equal to zero
     */
    public int getWidth()
    {
        Point pt = component.getSize();
        return pt.x;
    }

    /**
     * Get the current height of the drawable in pixels.
     *
     * @return A value greater than or equal to zero
     */
    public int getHeight()
    {
        Point pt = component.getSize();
        return pt.y;
    }

    /**
     * Swap the front and back buffers of this drawable now.
     */
    public void swapBuffers() throws GLException
    {
// From the AWT version. Do we need this for SWT?
//        lockToolkit();
        try
        {
            boolean didLock = false;

            if (drawable == 0)
            {
                if (lockSurface() == SURFACE_NOT_READY)
                  return;

                didLock = true;
            }

            GLX.glXSwapBuffers(display, drawable);

            if(didLock)
                unlockSurface();

        }
        finally
        {
//          unlockToolkit();
        }
    }

    //---------------------------------------------------------------
    // Methods defined by SurfaceController
    //---------------------------------------------------------------

    /**
     * Lock the surface now so that we can draw to it.
     *
     * @return One of the surface constants from this interface
     * @throws GLException The surface is already locked by someone else
     */
    public int lockSurface() throws GLException
    {
        if(!realized)
          return SURFACE_NOT_READY;

        if(drawable != 0)
          throw new GLException("Surface already locked");

        int window = OS.GTK_WIDGET_WINDOW(component.handle);
        display = OS.gdk_x11_drawable_get_xdisplay(window);

//        drawable = x11dsi.drawable();

/*
        ds = JAWT.getJAWT().GetDrawingSurface(component);
        if (ds == null) {
          // Widget not yet realized
          return LOCK_SURFACE_NOT_READY;
        }
        int res = ds.Lock();
        if ((res & JAWTFactory.JAWT_LOCK_ERROR) != 0) {
          throw new GLException("Unable to lock surface");
        }
        // See whether the surface changed and if so destroy the old
        // OpenGL context so it will be recreated (NOTE: removeNotify
        // should handle this case, but it may be possible that race
        // conditions can cause this code to be triggered -- should test
        // more)
        int ret = LOCK_SUCCESS;
        if ((res & JAWTFactory.JAWT_LOCK_SURFACE_CHANGED) != 0) {
          ret = LOCK_SURFACE_CHANGED;
        }
        dsi = ds.GetDrawingSurfaceInfo();
        if (dsi == null) {
          // Widget not yet realized
          ds.Unlock();
          JAWT.getJAWT().FreeDrawingSurface(ds);
          ds = null;
          return LOCK_SURFACE_NOT_READY;
        }
        x11dsi = (JAWT_X11DrawingSurfaceInfo) dsi.platformInfo();
        display = x11dsi.display();
        drawable = x11dsi.drawable();
        visualID = x11dsi.visualID();
        if (display == 0 || drawable == 0) {
          // Widget not yet realized
          ds.FreeDrawingSurfaceInfo(dsi);
          ds.Unlock();
          JAWT.getJAWT().FreeDrawingSurface(ds);
          ds = null;
          dsi = null;
          x11dsi = null;
          display = 0;
          drawable = 0;
          visualID = 0;
          return LOCK_SURFACE_NOT_READY;
        }
*/
        return SUCCESS;
    }

    /**
     * Check to see if the surface is currently locked.
     *
     * @return true if the surface is locked, false otherwise
     */
    public boolean isLockedSurface()
    {
        return (drawable != 0);
    }

    /**
     * Release the surface back to the OS. This may throw an exception if the
     * surface is already unlocked at this point.
     *
     * @throws GLException The surface is already unlocked
     */
    public void unlockSurface()
    {
        if(drawable == 0)
          throw new GLException("Surface already unlocked");

/*
        ds.FreeDrawingSurfaceInfo(dsi);
        ds.Unlock();
        JAWT.getJAWT().FreeDrawingSurface(ds);
        ds = null;
        dsi = null;
        x11dsi = null;
*/
        display = 0;
        drawable = 0;
        visualID = 0;
    }
}
