/*****************************************************************************
 *                     Yumetech, Inc Copyright (c) 2005
 *                               Java Source
 *
 * This source is licensed under the BSD-style License
 * Please read http://www.opensource.org/licenses/bsd-license.php for more
 * information or docs/BSD.txt in the downloaded code.
 *
 * This software comes with the standard NO WARRANTY disclaimer for any
 * purpose. Use it at your own risk. If there's a problem you get to fix it.
 *
 ****************************************************************************/

package org.j3d.opengl.swt.internal.ri.x11;

// External imports
import javax.media.opengl.*;

import org.eclipse.swt.widgets.Composite;

import com.sun.opengl.impl.x11.X11ExternalGLContext;
import com.sun.opengl.impl.x11.X11ExternalGLDrawable;

// Local imports
import org.j3d.opengl.swt.internal.ri.JOGLDrawableFactory;


/**
 * An implementation of the {@link GLDrawableFactory} that generates
 * SWT-specific capabilities for X11-based platforms.
 * <p>
 *
 *
 * @author Justin Couch
 * @version $Revision: 1.3 $
 */
public class X11DrawableFactory extends JOGLDrawableFactory
{
    /**
     * Create a new instance of this drawable factory. Note that end users
     * should never call this method directly. It is made public so that the
     * dynamic class loading defined by the specification can load this package
     * from another class in a different package.
     */
    public X11DrawableFactory()
    {
    }

    //---------------------------------------------------------------
    // Methods defined by GLDrawableFactory
    //---------------------------------------------------------------

    /**
     * Check to see if this system is capable of creating a Pbuffer. Some
     * older graphics cards are not capable of this.
     *
     * @return true if it is possible to create a GLPbuffer.
     */
    public boolean canCreateGLPbuffer()
    {
        return false;
    }

    /**
     * Creates a GLPbuffer with the given capabilites and dimensions.
     */
    public GLPbuffer createGLPbuffer(GLCapabilities capabilities,
                                     GLCapabilitiesChooser chooser,
                                     int initialWidth,
                                     int initialHeight,
                                     GLContext shareWith)
    {
        return null;
    }

    /**
     * <P> Creates a GLContext object representing an existing OpenGL
     * context in an external (third-party) OpenGL-based library. This
     * GLContext object may be used to draw into this preexisting
     * context using its {@link GL} and {@link
     * javax.media.opengl.glu.GLU} objects. New contexts created through
     * {@link GLDrawable}s may share textures and display lists with
     * this external context. </P>
     *
     * <P> The underlying OpenGL context must be current on the current
     * thread at the time this method is called. The user is responsible
     * for the maintenance of the underlying OpenGL context; calls to
     * <code>makeCurrent</code> and <code>release</code> on the returned
     * GLContext object have no effect. If the underlying OpenGL context
     * is destroyed, the <code>destroy</code> method should be called on
     * the <code>GLContext</code>. A new <code>GLContext</code> object
     * should be created for each newly-created underlying OpenGL
     * context.
     */
    public GLContext createExternalGLContext()
    {
        return new X11ExternalGLContext();
    }

    /**
     * Check to see if this card can create a drawable instance using
     * an external GL context.
     *
     * @return true if it is possible to create an external GLDrawable
     *   object via {@link #createExternalGLDrawable}.
     */
    public boolean canCreateExternalGLDrawable()
    {
        return true;
    }

    /**
     * Create a {@link GLDrawable} object representing an existing
     * OpenGL drawable in an external (third-party) OpenGL-based
     * library. This GLDrawable object may be used to create new,
     * fully-functional {@link GLContext}s on the OpenGL drawable. This
     * is useful when interoperating with a third-party OpenGL-based
     * library and it is essential to not perturb the state of the
     * library's existing context, even to the point of not sharing
     * textures or display lists with that context. </P>
     *
     */
    public GLDrawable createExternalGLDrawable()
    {
        return new X11ExternalGLDrawable();
    }

    //---------------------------------------------------------------
    // Methods defined by JOGLDrawableFactory
    //---------------------------------------------------------------

    /**
     * Create an instance of an on-screen drawable object.
     */
    protected GLDrawable createOnscreenDrawable(Composite widget,
                                                GLCapabilities capabilities,
                                                GLCapabilitiesChooser chooser)
    {
//        return new X11OnscreenGLDrawable(widget, capabilities, chooser);
        return null;
    }
}
