/*****************************************************************************
 *                                         Yumetech, Inc Copyright (c) 2005
 *                                                             Java Source
 *
 * This source is licensed under the BSD-style License
 * Please read http://www.opensource.org/licenses/bsd-license.php for more
 * information or docs/BSD.txt in the downloaded code.
 *
 * This software comes with the standard NO WARRANTY disclaimer for any
 * purpose. Use it at your own risk. If there's a problem you get to fix it.
 *
 ****************************************************************************/

package org.j3d.opengl.swt.internal.ri.osx;

// External imports
import javax.media.opengl.GLException;

import com.sun.opengl.impl.GLContextShareSet;
import com.sun.opengl.impl.macosx.agl.AGL;

// Local imports
// None

/**
 * Representation of an external GL context.
 * <p>
 *
 * OSX has some interesting issues with OpenGL context handling. Since there
 * are two windowing system APIs in use, they are not directly compatible. It
 * is not possible to share a context from a Cocoa app with a Carbon one. Since
 * this is for SWT, and there are issues running SWT and AWT together already
 * on a mac, we can assume that there will only be SWT, hence Carbon-only.
 *
 * @author Justin Couch
 * @version $Revision: 1.2 $
 */
public class MacExternalGLContext extends MacGLContext
{
    /** First time through making a context current. */
    private boolean firstMakeCurrent;

    /** Have we hooked to the external context yet. */
    private boolean created;

    public MacExternalGLContext()
    {
        super(null, null);

        firstMakeCurrent = true;
        created = true;

        aglContextID = AGL.aglGetCurrentContext();
        if(aglContextID == 0)
            throw new GLException("Error: attempted to make an " +
                                  "external GLContext without a drawable/context current");

        GLContextShareSet.contextCreated(this);
        resetGLFunctionAvailability();
    }

    protected boolean create()
    {
        return true;
    }

    protected int makeCurrentImpl() throws GLException
    {
        if(firstMakeCurrent)
        {
            firstMakeCurrent = false;
            return CONTEXT_CURRENT_NEW;
        }

        return CONTEXT_CURRENT;
    }

    protected void releaseImpl() throws GLException
    {
    }

    protected void destroyImpl() throws GLException
    {
        created = false;
        GLContextShareSet.contextDestroyed(this);
    }

    public boolean isCreated()
    {
        return created;
    }
}
