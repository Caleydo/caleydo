/*****************************************************************************
 *                     Yumetech, Inc Copyright (c) 2005
 *                               Java Source
 *
 * This source is licensed under the BSD-style License
 * Please read http://www.opensource.org/licenses/bsd-license.php for more
 * information or docs/BSD.txt in the downloaded code.
 *
 * This software comes with the standard NO WARRANTY disclaimer for any
 * purpose. Use it at your own risk. If there's a problem you get to fix it.
 *
 ****************************************************************************/

package org.j3d.opengl.swt.internal.ri.x11;

// External imports
import javax.media.opengl.*;

import com.sun.opengl.impl.GLContextShareSet;
import com.sun.opengl.impl.x11.GLX;

// Local imports
import org.j3d.opengl.swt.internal.ri.SurfaceController;

/**
 * Context for onscreen drawable objects in the X11 environment.
 *
 * @author Justin Couch
 * @version $Revision: 1.1 $
 */
class X11OnscreenGLContext extends X11GLContext
{
    private static final String NO_DELETE_ERR =
        "Unable to delete old GL context after surface changed";

    /** Handler for dealing with surface locking */
    private SurfaceController lockHandler;

    /**
     * Create a new on-screen GL context
     *
     * @param drawable The drawable associated with this context
     * @param locker The surface lock control handler
     * @param shareWith The optional context to share data with
     */
    X11OnscreenGLContext(X11GLDrawable drawable,
                         SurfaceController locker,
                         GLContext shareWith)
    {
        super(drawable, shareWith);

        lockHandler = locker;
    }

    /**
     * Make the context current now.
     */
    protected int makeCurrentImpl() throws GLException
    {
        int ret_val = 0;

        try
        {
            int lockRes = lockHandler.lockSurface();

            switch(lockRes)
            {
                case SurfaceController.SURFACE_NOT_READY:
                    ret_val = CONTEXT_NOT_CURRENT;
                    break;

                case SurfaceController.SURFACE_CHANGED:
                    if(context != 0)
                    {
                        GLX.glXDestroyContext(mostRecentDisplay, context);
                        GLContextShareSet.contextDestroyed(this);

                        context = 0;
                    }
                    ret_val = super.makeCurrentImpl();
                    break;

                default:
                    ret_val = super.makeCurrentImpl();
            }
        }
        catch(RuntimeException re)
        {
            try
            {
                // This may also toss an exception due to something that
                // messed up in the above code, so catch and ignore here.
                lockHandler.unlockSurface();
            }
            catch(RuntimeException re2)
            {
            }
        }

        return ret_val;
/*
        try {
        int lockRes = drawable.lockSurface();
        if (lockRes == X11OnscreenGLDrawable.LOCK_SURFACE_NOT_READY) {
            return CONTEXT_NOT_CURRENT;
        }
        if (lockRes == X11OnscreenGLDrawable.LOCK_SURFACE_CHANGED) {
            if (context != 0) {
                GLX.glXDestroyContext(mostRecentDisplay, context);
                GLContextShareSet.contextDestroyed(this);
                if (DEBUG) {
                    System.err.println(getThreadName() + ": !!! Destroyed OpenGL context " + toHexString(context) + " due to JAWT_LOCK_SURFACE_CHANGED");
                }
                context = 0;
            }
        }

        int ret = super.makeCurrentImpl();
        return ret;

        } catch (RuntimeException e) {
            try {
            drawable.unlockSurface();
            } catch (Exception e2) {
            // do nothing if unlockSurface throws
            }
            throw(e);
        }
*/
    }

    /**
     * Release the underlying context implementation.
     */
    protected void releaseImpl() throws GLException
    {
        try
        {
            super.releaseImpl();
        }
        catch(GLException gle)
        {
        }

        lockHandler.unlockSurface();
    }

    protected void create()
    {
        createContext(true);
    }
}
