/*****************************************************************************
 *                     Yumetech, Inc Copyright (c) 2005
 *                               Java Source
 *
 * This source is licensed under the BSD-style License
 * Please read http://www.opensource.org/licenses/bsd-license.php for more
 * information or docs/BSD.txt in the downloaded code.
 *
 * This software comes with the standard NO WARRANTY disclaimer for any
 * purpose. Use it at your own risk. If there's a problem you get to fix it.
 *
 ****************************************************************************/

package org.j3d.opengl.swt.internal.ri;

// External imports
import org.j3d.opengl.swt.SWTGraphicsConfiguration;

import org.eclipse.swt.opengl.GLData;

// Local imports
// None

/**
 * A wrapper for SWT graphics configuration information allowing it to be
 * handled in a toolkit-independent manner.
 *
 * @author Justin Couch
 * @version $Revision: 1.1 $
 */
public class JOGLGraphicsConfiguration implements SWTGraphicsConfiguration
{
    /** The GL information in a way the stock SWT GLCanvas likes it */
    private GLData swtData;

    /**
     * Create a new isntance of this graphics configuration that wraps the
     * given SWT-specific information in a platform independent way.
     */
    public JOGLGraphicsConfiguration(GLData data)
    {
        swtData = data;
    }

    //---------------------------------------------------------------
    // Methods defined by SWTGraphicsConfiguration
    //---------------------------------------------------------------

    /**
     * Get the SWT representation of GL data information.
     *
     * @param The data reference
     */
    public GLData getGLData()
    {
        return swtData;
    }
}
