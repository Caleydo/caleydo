/*****************************************************************************
 *                     Yumetech, Inc Copyright (c) 2005
 *                               Java Source
 *
 * This source is licensed under the BSD-style License
 * Please read http://www.opensource.org/licenses/bsd-license.php for more
 * information or docs/BSD.txt in the downloaded code.
 *
 * This software comes with the standard NO WARRANTY disclaimer for any
 * purpose. Use it at your own risk. If there's a problem you get to fix it.
 *
 ****************************************************************************/

package org.j3d.opengl.swt.internal.ri.osx;

// External imports
import javax.media.opengl.*;

import com.sun.opengl.impl.GLContextShareSet;
import com.sun.opengl.impl.macosx.agl.AGL;

// Local imports
import org.j3d.opengl.swt.internal.ri.SurfaceController;

/**
 * Representation of context management for onscreen surfaces
 *
 * @author Justin Couch
 * @version $Revision: 1.4 $
 */
class MacOnscreenGLContext extends MacGLContext
{
    private static final String NO_DELETE_ERR =
        "Unable to delete old GL context after surface changed";

    /** Handler for dealing with surface locking */
    private SurfaceController lockHandler;

    /**
     * Create a new instance of the onscreen surface controller.
     */
    MacOnscreenGLContext(MacGLDrawable drawable,
                         SurfaceController locker,
                         GLContext shareWith)
    {
        super(drawable, shareWith);

        lockHandler = locker;
    }

    /**
     * Make the context current now.
     */
    protected int makeCurrentImpl() throws GLException
    {
        int ret_val = 0;

        try
        {
            int lockRes = lockHandler.lockSurface();

            switch(lockRes)
            {
                case SurfaceController.SURFACE_NOT_READY:
                    ret_val = CONTEXT_NOT_CURRENT;
                    break;

                case SurfaceController.SURFACE_CHANGED:
                    destroyImpl();

                    ret_val = super.makeCurrentImpl();

                    if((ret_val == CONTEXT_CURRENT) ||
                       (ret_val == CONTEXT_CURRENT_NEW))
                    {
                        // Ken's comments:
                        // Assume the canvas might have been resized or moved
                        // and tell the OpenGL context to update itself. This
                        // used to be done only upon receiving a reshape event
                        // but that doesn't appear to be sufficient.
                        AGL.aglUpdateContext(aglContextID);
                    }
                    else
                    {
                        // View might not have been ready
                        lockHandler.unlockSurface();
                    }
                    break;

                default:

                    ret_val = super.makeCurrentImpl();
            }
        }
        catch(RuntimeException re)
        {
            try
            {
System.out.println("exception locking surface" + re);
re.printStackTrace();
                // This may also toss an exception due to something that
                // messed up in the above code, so catch and ignore here.
                lockHandler.unlockSurface();
            }
            catch(RuntimeException re2)
            {
System.out.println("Exception unlocking failed lock "  + re2);
re2.printStackTrace();
            }
        }

        return ret_val;
    }

    /**
     * Release the underlying context implementation.
     */
    protected void releaseImpl() throws GLException
    {
        try
        {
            super.releaseImpl();
        }
        catch(GLException gle)
        {
        }

        lockHandler.unlockSurface();
    }

    /**
     * Local convenience method to swap the buffers right now. Makes access
     * to the local context pointer.
     */
    void swapBuffers() throws GLException
    {
        AGL.aglSwapBuffers(aglContextID);
    }
}
