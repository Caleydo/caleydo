/*****************************************************************************
 *                     Yumetech, Inc Copyright (c) 2005 - 2006
 *                               Java Source
 *
 * This source is licensed under the BSD-style License
 * Please read http://www.opensource.org/licenses/bsd-license.php for more
 * information or docs/BSD.txt in the downloaded code.
 *
 * This software comes with the standard NO WARRANTY disclaimer for any
 * purpose. Use it at your own risk. If there's a problem you get to fix it.
 *
 ****************************************************************************/

package org.j3d.opengl.swt;

// External imports
import javax.media.opengl.GLContext;
import javax.media.opengl.GLDrawable;
import javax.media.opengl.GLException;

import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;

// Local imports
// None

/**
 * Internal handler for listening for SWT dispose events and transforming those
 * into a call to destroy the GLContext.
 * <p>
 *
 * Automatically destroys the context and marks the drawable as being
 * unrealised with the event is called. This is a last-resort system so that if
 * the end user has forgotten to clean up, we'll do it for them. If they have
 * already cleaned up, then the internal code will generate an exception when
 * we attempt to. There's not much we can do about that, but we can catch them
 * and not report anything further.
 *
 * @author Justin Couch
 * @version $Revision: 1.3 $
 */
class DisposeHandler implements DisposeListener
{
    /** The context to dispose of */
    private GLContext context;

    /**
     * Create a new isntance of this graphics device that wraps the
     * given SWT-specific information in a platform independent way.
     */
    DisposeHandler(GLContext context)
    {
        this.context = context;
    }

    //---------------------------------------------------------------
    // Methods defined by DisposeListener
    //---------------------------------------------------------------

    /**
     * Notification that the widget has been disposed.
     *
     * @param e The event that caused this method to be called
     */
    public void widgetDisposed(DisposeEvent e)
    {
        GLDrawable d = context.getGLDrawable();

        try
        {
            context.release();
            context.destroy();

            d.setRealized(false);
        }
        catch(GLException ge)
        {
            // ignore it because someone has already beaten us to the cleanup
            // calls.
        }
    }
}
