/*****************************************************************************
 *                                         Yumetech, Inc Copyright (c) 2005
 *                                                             Java Source
 *
 * This source is licensed under the BSD-style License
 * Please read http://www.opensource.org/licenses/bsd-license.php for more
 * information or docs/BSD.txt in the downloaded code.
 *
 * This software comes with the standard NO WARRANTY disclaimer for any
 * purpose. Use it at your own risk. If there's a problem you get to fix it.
 *
 ****************************************************************************/

package org.j3d.opengl.swt.internal.ri.osx;

// External imports
import javax.media.opengl.*;

import com.sun.opengl.impl.*;

/**
 * Representation of external drawable for onscreen surfaces
 *
 * @author Justin Couch
 * @version $Revision: 1.1 $
 */
public class MacExternalGLDrawable extends MacGLDrawable
{
    public MacExternalGLDrawable()
    {
        super(new GLCapabilities(), null);

//        carbonPort = AGL.getDrawable()
    }

    public GLContext createContext(GLContext shareWith)
    {
        return new MacGLContext(this, shareWith);
    }

    public void setSize(int newWidth, int newHeight)
    {
        throw new GLException("Should not call this");
    }

    public int getWidth()
    {
        throw new GLException("Should not call this");
    }

    public int getHeight()
    {
        throw new GLException("Should not call this");
    }

    public void destroy()
    {
    }
}
