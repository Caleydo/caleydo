/*****************************************************************************
 *                     Yumetech, Inc Copyright (c) 2005
 *                               Java Source
 *
 * This source is licensed under the BSD-style License
 * Please read http://www.opensource.org/licenses/bsd-license.php for more
 * information or docs/BSD.txt in the downloaded code.
 *
 * This software comes with the standard NO WARRANTY disclaimer for any
 * purpose. Use it at your own risk. If there's a problem you get to fix it.
 *
 ****************************************************************************/

package org.j3d.opengl.swt.internal.ri.windows;

// External imports
import javax.media.opengl.*;

import com.sun.opengl.impl.GLContextShareSet;
import com.sun.opengl.impl.windows.WGL;
import com.sun.opengl.impl.windows.WindowsGLContext;
import com.sun.opengl.impl.windows.WindowsGLDrawable;

// Local imports
import org.j3d.opengl.swt.internal.ri.SurfaceController;

/**
 * Representation of context management for onscreen surfaces
 *
 * @author Justin Couch
 * @version $Revision: 1.2 $
 */
class WindowsOnscreenGLContext extends WindowsGLContext
{
    private static final String NO_DELETE_ERR =
        "Unable to delete old GL context after surface changed";

    /** Handler for dealing with surface locking */
    private SurfaceController lockHandler;

    /**
     * Create a new instance of the onscreen surface controller.
     */
    WindowsOnscreenGLContext(WindowsGLDrawable drawable,
                             SurfaceController locker,
                             GLContext shareWith)
    {
        super(drawable, shareWith);

        lockHandler = locker;
    }

    /**
     * Make the context current now.
     */
    protected int makeCurrentImpl() throws GLException
    {
        int ret_val = 0;

        try
        {
            int lockRes = lockHandler.lockSurface();

            switch(lockRes)
            {
                case SurfaceController.SURFACE_NOT_READY:
                    ret_val = CONTEXT_NOT_CURRENT;
                    break;

                case SurfaceController.SURFACE_CHANGED:
                    if(hglrc != 0)
                    {
                        if(!WGL.wglDeleteContext(hglrc))
                            throw new GLException(NO_DELETE_ERR);

                        GLContextShareSet.contextDestroyed(this);

                        hglrc = 0;
                    }
                    ret_val = CONTEXT_CURRENT_NEW;
                    break;

                default:
                    ret_val = super.makeCurrentImpl();
            }
        }
        catch(RuntimeException re)
        {
            try
            {
                // This may also toss an exception due to something that
                // messed up in the above code, so catch and ignore here.
                lockHandler.unlockSurface();
            }
            catch(RuntimeException re2)
            {
            }
        }

        return ret_val;
    }

    /**
     * Release the underlying context implementation.
     */
    protected void releaseImpl() throws GLException
    {
        try
        {
            super.releaseImpl();
        }
        catch(GLException gle)
        {
        }

        lockHandler.unlockSurface();
    }
}
