/*****************************************************************************
 *                                         Yumetech, Inc Copyright (c) 2005
 *                                                             Java Source
 *
 * This source is licensed under the BSD-style License
 * Please read http://www.opensource.org/licenses/bsd-license.php for more
 * information or docs/BSD.txt in the downloaded code.
 *
 * This software comes with the standard NO WARRANTY disclaimer for any
 * purpose. Use it at your own risk. If there's a problem you get to fix it.
 *
 ****************************************************************************/

package org.j3d.opengl.swt.internal.ri.osx;

// External imports
import com.sun.gluegen.runtime.DynamicLookupHelper;
import com.sun.opengl.impl.macosx.agl.AGL;

// Local imports
// None

/**
 * Utilities for local AGL implementation interface.
 *
 * @author Justin Couch
 * @version $Revision: 1.1 $
 */
public class AGLUtils implements DynamicLookupHelper
{

    /** The shared instance of us */
    private static AGLUtils instance;

    /** Private constructor to prevent direct instantiation */
    private AGLUtils()
    {
    }

    public static DynamicLookupHelper getLookupHelper()
    {
        if(instance == null)
            instance = new AGLUtils();

        return instance;
    }

    /** Dynamically looks up the given function. */
    public long dynamicLookupFunction(String glFuncName)
    {
        return AGL.getProcAddress(glFuncName);
    }
}
