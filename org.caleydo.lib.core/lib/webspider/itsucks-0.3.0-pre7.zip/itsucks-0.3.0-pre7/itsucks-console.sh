#!/bin/sh

java -jar lib/itsucks-console-0.3.0-pre7.jar $1
