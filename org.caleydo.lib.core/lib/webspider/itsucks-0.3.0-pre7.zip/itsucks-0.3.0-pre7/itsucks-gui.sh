#!/bin/sh

java -Xmx512M -jar itsucks-gui.jar
