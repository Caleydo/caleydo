#!/bin/sh

java -jar lib/itsucks-console-0.3.1.jar $1
