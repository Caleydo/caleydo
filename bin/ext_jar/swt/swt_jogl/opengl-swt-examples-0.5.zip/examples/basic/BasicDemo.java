/*****************************************************************************
 *                     Yumetech, Inc Copyright (c) 2005
 *                               Java Source
 *
 * This source is licensed under the BSD-style License
 * Please read http://www.opensource.org/licenses/bsd-license.php for more
 * information or docs/BSD.txt in the downloaded code.
 *
 * This software comes with the standard NO WARRANTY disclaimer for any
 * purpose. Use it at your own risk. If there's a problem you get to fix it.
 *
 ****************************************************************************/

// External imports
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.widgets.*;

import javax.media.opengl.GL;
import javax.media.opengl.GLContext;
import javax.media.opengl.GLDrawable;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;

// Local imports
import org.j3d.opengl.swt.GLCanvas;

/**
 * The first demonstration of using the SWT bindings to the JSR-231 code.
 * <p>
 *
 * The demo creates the basic application output and then manually deals with
 * refreshing the OpenGL state. It does this by creating an endless thread that
 * just loops calling makeCurrent(), painting a basic rectangle, then releasing
 * the context, sleeping a little bit, then repeating over and over.
 *
 * @author Justin Couch
 * @version $Revision: 1.2 $
 */
public class BasicDemo implements Runnable
{
    /** The GLContext we're drawing with */
    private GLContext context;

    /** The GLDrawble we're drawing to */
    private GLDrawable drawable;

    /** The display we're drawing to */
    private static Display display;

    /**
     * Create a new demo that runs on the given shell as parent.
     */
    public BasicDemo(Shell parent)
    {
        GLCanvas canvas = new GLCanvas(parent, SWT.NONE);
        context = canvas.getGLContext();
        drawable = canvas.getGLDrawable();
    }

    public static void main(String [] args)
    {
        System.setProperty("opengl.factory.class.name",
                           "org.j3d.opengl.swt.SWTRIDrawableFactory");

        Shell shell = new Shell();
        shell.setLayout(new FillLayout());
        BasicDemo demo = new BasicDemo(shell);

        shell.setSize (640, 480);
        shell.open();

        display = shell.getDisplay();

        Thread th = new Thread(demo);
        th.start();


        while(!shell.isDisposed())
        {
            if(!display.readAndDispatch())
                display.sleep();
        }

        display.dispose();
    }

    //----------------------------------------------------------
    // Methods defined by Runnable
    //----------------------------------------------------------

    /**
     * Run the repainting thread now.
     */
    public void run()
    {
        // Do our initial setup of the GL pipeline
        int state = context.makeCurrent();

        GL gl = context.getGL();

        System.out.println("GL_VENDOR: " + gl.glGetString(GL.GL_VENDOR));

        gl.glViewport(0, 0, 640, 480);
        gl.glEnable(GL.GL_DEPTH_TEST);
        gl.glEnable(GL.GL_NORMALIZE);

        context.release();

        while(true)
        {
            context.makeCurrent();
            gl = context.getGL();

            gl.glClear(GL.GL_DEPTH_BUFFER_BIT | GL.GL_COLOR_BUFFER_BIT);

            gl.glLoadIdentity();
            gl.glTranslatef(-0.5f,0,-0.9f);
            gl.glBegin(GL.GL_TRIANGLES);
            gl.glColor3f(1, 0, 0);
            gl.glVertex3f( 0.0f, 0.3f, 0);
            gl.glVertex3f(-0.3f,-0.3f, 0);
            gl.glVertex3f( 0.3f,-0.3f, 0);
            gl.glEnd();

            gl.glTranslatef(1f, 0, 0);
            gl.glBegin(GL.GL_QUADS);
            gl.glColor3f(0, 1, 0);
            gl.glVertex3f(-0.3f, 0.3f, 0);
            gl.glVertex3f( 0.3f, 0.3f, 0);
            gl.glVertex3f( 0.3f,-0.3f, 0);
            gl.glVertex3f(-0.3f,-0.3f, 0);
            gl.glEnd();

            drawable.swapBuffers();
            context.release();

            try
            {
                Thread.sleep(100);
            }
            catch(InterruptedException ie)
            {
            }
        }
    }
}
