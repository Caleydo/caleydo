/**
 * This is a copy of the code from the Eclipse SWT bug ID 110757 illustrating the
 * use of the external drawable functionality. You can directly download the code
 * from this link:
 *
 * https://bugs.eclipse.org/bugs/attachment.cgi?id=30386
 *
 * The only changed thing is the name of the class.
 */

import javax.media.opengl.GL;
import javax.media.opengl.GLContext;
import javax.media.opengl.GLDrawable;
import javax.media.opengl.GLDrawableFactory;
import javax.media.opengl.glu.GLU;

import org.eclipse.swt.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.opengl.*;
import org.eclipse.swt.widgets.*;

public class ExternalDrawableDemo {
    static void drawTorus(GL gl, float r, float R, int nsides, int rings) {
        float ringDelta = 2.0f * (float) Math.PI / rings;
        float sideDelta = 2.0f * (float) Math.PI / nsides;
        float theta = 0.0f;
        float cosTheta = 1.0f;
        float sinTheta = 0.0f;
        for (int i = rings - 1; i >= 0; i--) {
            float theta1 = theta + ringDelta;
            float cosTheta1 = (float) Math.cos(theta1);
            float sinTheta1 = (float) Math.sin(theta1);
            gl.glBegin(GL.GL_QUAD_STRIP);
            float phi = 0.0f;
            for (int j = nsides; j >= 0; j--) {
                phi += sideDelta;
                float cosPhi = (float) Math.cos(phi);
                float sinPhi = (float) Math.sin(phi);
                float dist = R + r * cosPhi;
                gl.glNormal3f(cosTheta1 * cosPhi, -sinTheta1 * cosPhi, sinPhi);
                gl.glVertex3f(cosTheta1 * dist, -sinTheta1 * dist, r * sinPhi);
                gl.glNormal3f(cosTheta * cosPhi, -sinTheta * cosPhi, sinPhi);
                gl.glVertex3f(cosTheta * dist, -sinTheta * dist, r * sinPhi);
            }
            gl.glEnd();
            theta = theta1;
            cosTheta = cosTheta1;
            sinTheta = sinTheta1;
        }
    }

    public static void main(String [] args) {
        final Display display = new Display();
        Shell shell = new Shell (display);
        shell.setLayout(new FillLayout());
        GLData data = new GLData ();
        data.doubleBuffer = true;
        final GLCanvas canvas = new GLCanvas (shell, SWT.NONE, data);
        canvas.setCurrent();
        shell.setSize (640, 480);
        shell.open();

        GLDrawable drawable = GLDrawableFactory.getFactory().createExternalGLDrawable();
        GLContext context = drawable.createContext(null);
        final GL gl = context.getGL ();
        System.out.println("GL_VENDOR: " + gl.glGetString(GL.GL_VENDOR));

        int width = 640, height = 480;
        float fAspect = (float) width / (float) height;

        gl.glViewport(0, 0, width, height);
        gl.glMatrixMode(GL.GL_PROJECTION);  // select the projection matrix
        gl.glLoadIdentity();                // reset the projection matrix
        GLU glu = new GLU();
        glu.gluPerspective(45.0f, fAspect, 0.5f, 400.0f);
        gl.glMatrixMode(GL.GL_MODELVIEW);   // select the modelview matrix
        gl.glLoadIdentity();
        gl.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
        gl.glColor3f(1.0f, 0.0f, 0.0f);
        gl.glHint(GL.GL_PERSPECTIVE_CORRECTION_HINT, GL.GL_NICEST);
        gl.glClearDepth(1.0);
        gl.glLineWidth(2);
        gl.glEnable(GL.GL_DEPTH_TEST);

        display.asyncExec(new Runnable() {
            int rot = 0;
            public void run() {
                if (!canvas.isDisposed()) {
                    canvas.setCurrent();
                    gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
                    gl.glClearColor(.3f, .5f, .8f, 1.0f);
                    gl.glLoadIdentity();
                    gl.glTranslatef(0.0f, 0.0f, -10.0f);
                    gl.glRotatef(0.15f * rot, 2.0f * ((float) rot), 10.0f * ((float) rot), 1.0f);
                    gl.glRotatef(0.3f * rot, 3.0f * ((float) rot), 1.0f * ((float) rot), 1.0f);
                    rot++;
                    gl.glPolygonMode(GL.GL_FRONT_AND_BACK, GL.GL_LINE);
                    gl.glColor3f(0.9f, 0.9f, 0.9f);
                    drawTorus(gl, 1, 1.9f + ((float) Math.sin((0.004f * rot))), 15, 15);
                    canvas.swapBuffers();

                    display.asyncExec(this);
                }
            }
        });

        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
        display.dispose();
    }
}
